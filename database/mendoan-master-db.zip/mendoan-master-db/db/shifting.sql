CREATE TABLE `shifting` (
  `user_id` varchar(50) NOT NULL,
  `shifttype` varchar(1) NOT NULL,
  `startdate` varchar(10) NOT NULL,
  `enddate` varchar(10) NOT NULL,
  PRIMARY KEY (`user_id`,`shifttype`,`startdate`,`enddate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1