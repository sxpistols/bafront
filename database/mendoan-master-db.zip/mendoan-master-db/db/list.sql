CREATE TABLE `list` (
  `id` varchar(50) NOT NULL,
  `board_id` varchar(50) NOT NULL,
  `list_name` varchar(100) NOT NULL,
  `closed` varchar(50) NOT NULL,
  `pos` varchar(50) NOT NULL,
  `softlimit` varchar(50) NOT NULL,
  `subscribed` varchar(50) NOT NULL,
  PRIMARY KEY (`id`,`board_id`,`list_name`,`closed`,`pos`,`softlimit`,`subscribed`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1