CREATE TABLE `boards` (
  `id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`,`name`,`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4