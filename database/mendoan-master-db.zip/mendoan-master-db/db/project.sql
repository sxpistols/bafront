CREATE TABLE `project` (
  `id_project` varchar(250) NOT NULL,
  `project` varchar(250) DEFAULT NULL,
  `client` varchar(50) DEFAULT NULL,
  `po_name` varchar(250) DEFAULT NULL,
  `cr_name` varchar(250) DEFAULT NULL,
  `jenis` varchar(20) DEFAULT NULL,
  `mulai` varchar(10) NOT NULL,
  `selesai` varchar(10) NOT NULL,
  `posisi` varchar(100) NOT NULL,
  `resource_name` varchar(100) NOT NULL,
  `createdby` varchar(50) DEFAULT NULL,
  `createdate` varchar(20) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_project`,`mulai`,`selesai`,`posisi`,`resource_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4