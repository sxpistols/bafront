CREATE TABLE `board` (
  `id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `url` varchar(250) NOT NULL,
  `shortUrl` varchar(100) NOT NULL,
  `idOrganization` varchar(50) NOT NULL,
  `dateLastActivity` varchar(30) DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1