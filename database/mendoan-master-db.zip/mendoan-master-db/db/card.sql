CREATE TABLE `card` (
  `id` varchar(50) NOT NULL,
  `board_id` varchar(50) NOT NULL,
  `list_id` varchar(50) NOT NULL,
  `card_name` varchar(100) NOT NULL,
  `closed` varchar(50) DEFAULT NULL,
  `pos` varchar(50) NOT NULL,
  `duedate` varchar(30) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`,`board_id`,`list_id`,`card_name`,`pos`,`duedate`,`url`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1