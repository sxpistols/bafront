CREATE TABLE `boardactions` (
  `id` varchar(50) NOT NULL,
  `board_id` varchar(50) NOT NULL,
  `list_id` varchar(50) NOT NULL,
  `card_id` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  `creator_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `text` varchar(3000) DEFAULT NULL,
  `attachment_id` varchar(50) DEFAULT NULL,
  `attachment_name` varchar(100) DEFAULT NULL,
  `attachment_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`,`board_id`,`list_id`,`card_id`,`type`,`tanggal`,`creator_id`,`fullname`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1