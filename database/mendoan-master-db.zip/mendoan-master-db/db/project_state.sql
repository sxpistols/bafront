CREATE TABLE `project_state` (
  `id_project` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id_project`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4