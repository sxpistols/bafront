CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(120) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `createdate` varchar(20) NOT NULL,
  `createdby` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama` (`nama`),
  UNIQUE KEY `alamat` (`alamat`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4