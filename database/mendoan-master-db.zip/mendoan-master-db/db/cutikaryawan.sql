CREATE TABLE `cutikaryawan` (
  `fullname` varchar(50) NOT NULL,
  `tanggal_cuti` varchar(10) NOT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fullname`,`tanggal_cuti`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1