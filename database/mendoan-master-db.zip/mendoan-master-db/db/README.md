# [TABLE STRUCTURE & DATA TABLE BACKUP] (http://www.google.com)

Database yang digunakan adalah MySQL, dan nama database adalah employee

> ** Pada repo dir ini terdiri dari:

- Structure tabel-tabel yang dibutuhkan
- Backup data untuk semua tabel per tanggal 5 Maret 2021
