CREATE TABLE `trello_karyawan` (
  `fullname` varchar(150) DEFAULT NULL,
  `trelloid` varchar(200) DEFAULT NULL,
  UNIQUE KEY `fullN` (`fullname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1